chrome.runtime.onInstalled.addListener(e=>{e.reason==="install"&&chrome.tabs.create({url:"https://my-jobs-tracker.vercel.app/login?installed=true"})});
